import React from "react";
import PageTitle from "../../components/Common/PageTitle";

function AboutScreen() {
  return (
    <div>
      <div className="p-4">
        <div className="bg-white rounded-xl p-3 font-title">
          <PageTitle title="About Me" />
          <div className="mt-4 mb-5 flex flex-row items-center">
            <img
              src="https://scontent.fluh1-1.fna.fbcdn.net/v/t39.30808-6/278616597_5134490783308915_1772996860798636278_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=y4lJx5i-xZ4AX-FbEeS&_nc_ht=scontent.fluh1-1.fna&oh=00_AfCdu08SYLLVwCxKeVPXOcAzaJXJOIDapDclmZsBN3zhvA&oe=660F9085"
              className="h-12 mr-3"
              alt="Git"
            />
            <div>
              <a
                href="https://github.com/Anukoolrst"
                target={"_blank"}
                className="underline cursor-pointer"
                rel="noreferrer"
              >
                Hi, I'm Anukool Raj Singh
              </a>
              <h1> Invoice Maker for your business.</h1>
            </div>
          </div>

          <PageTitle title="Invoice Maker" />
          <div className="mt-2 pl-4 text-sm">
            <ul class="list-disc">
              <li> Can Easily Pre-Manage Your Products</li>
              <li> Can Easily Pre-Manage Your Clients</li>
              <li> Can Export PDF </li>
              <li> Can Export Image </li>
            </ul>
          </div>
          <div className="font-title mt-3 mb-5">
            <div>
              🤝 I’m looking job in React js 💌
            </div>
            <div>
              📫 How to reach me{" "}
              <a
                href="mailto:rs.anukool@gmail.com"
                className="underline cursor-pointer"
              >
                rs.anukool@gmail.com
              </a>{" "}
              (or){" "}
              <a
                href="https://www.facebook.com/anukool.thapa1"
                target={"_blank"}
                className="underline cursor-pointer"
                rel="noreferrer"
              >
                facebook
              </a>
            </div>
            <div>
              <span>🎁 </span>
              <a
                href="https://github.com/Anucoolrst/"
                className="underline cursor-pointer"
                target={"_blank"}
                rel="noreferrer"
              >
                {" "}
                Repo Link Here
              </a>
            </div>
          </div>

          <PageTitle title="Build By" />
          <div className="mt-2 mb-5 pl-4 text-sm">
            <ul class="list-disc">
              <li> Framer Motion For each component Animation</li>
              <li> Lottiefiles For Dashboard Widgets Icons</li>
              <li> IndexedDB for Local Storage </li>
              <li> ReactJS </li>
            </ul>
          </div>

          <PageTitle title="Contact" />
          <div className="mt-2 pl-1 text-sm">
            <a
              // href="tel:+959420059241"
              className="underline cursor-pointer"
              target={"_blank"}
              rel="noreferrer"
            >
              {" "}
              eight one two six three seven five seven four (get the last digit by shooting mail on the above id)
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
export default AboutScreen;
