module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        'title': ['"Josefin Sans"', 'cursive']
      }
    }
  },
  plugins: [],
};

